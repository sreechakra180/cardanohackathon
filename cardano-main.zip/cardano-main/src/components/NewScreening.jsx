import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import CardContainer from './common/CardContainer';
import InputField from './common/InputField';
import PrimaryButton from './common/PrimaryButton';

const NewScreening = ({ onRunScreening }) => {
    const [patientId, setPatientId] = useState('');
    const [eyeImage, setEyeImage] = useState(null);
    const [nailImage, setNailImage] = useState(null);
    const [eyePreview, setEyePreview] = useState(null);
    const [nailPreview, setNailPreview] = useState(null);
    const [isDemoMode, setIsDemoMode] = useState(false);

    const handleImageChange = (e, type) => {
        const file = e.target.files[0];
        if (file) {
            const url = URL.createObjectURL(file);
            if (type === 'eye') {
                setEyeImage(file);
                setEyePreview(url);
            } else {
                setNailImage(file);
                setNailPreview(url);
            }
        }
    };

    const removeImage = (type) => {
        if (type === 'eye') {
            setEyeImage(null);
            setEyePreview(null);
        } else {
            setNailImage(null);
            setNailPreview(null);
        }
    };

    const toggleDemoMode = () => {
        const newDemoState = !isDemoMode;
        setIsDemoMode(newDemoState);

        if (newDemoState) {
            // Auto-fill for demo
            setPatientId(Math.floor(100 + Math.random() * 900).toString());
            // In a real app we'd fetch actual files, here we just set preview URLs if available or leave empty
            // For the hackathon demo, we can just simulate the "ready" state or skip validation
        } else {
            setPatientId('');
            setEyeImage(null);
            setEyePreview(null);
            setNailImage(null);
            setNailPreview(null);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isDemoMode) {
            // Immediate execution with dummy data if images are missing
            onRunScreening({
                patientId: patientId || 'DEMO-123',
                eyeImage: eyeImage,
                nailImage: nailImage
            });
        } else {
            onRunScreening({ patientId, eyeImage, nailImage });
        }
    };

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main input area */}
                <div className="col-span-2">
                    <div className="p-4 bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/40 rounded-md shadow-sm">
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Screening Input</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Upload the retinal and nail images for this patient.</p>

                        <form onSubmit={handleSubmit} className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">Patient ID</label>
                                <input value={patientId} onChange={(e) => setPatientId(e.target.value)} placeholder="Enter Patient ID" className="mt-2 w-full px-3 py-2 border rounded-md text-sm bg-white dark:bg-slate-900/30 border-slate-200 dark:border-slate-700" required={!isDemoMode} />
                                <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">Use an internal patient identifier where available.</div>
                            </div>

                            <div className="flex items-center gap-3">
                                <div className="flex-1">
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">Retinal image</label>
                                    <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'eye')} className="mt-2 w-full text-sm text-slate-600" required={!isDemoMode} />
                                    <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">Clear, well-lit retinal images improve results.</div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">Nail image</label>
                                <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'nail')} className="mt-2 w-full text-sm text-slate-600" required={!isDemoMode} />
                                <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">Include the full nail bed if possible.</div>
                            </div>

                            <div className="md:col-span-2 flex items-center gap-3 mt-2">
                                <button type="submit" className="px-4 py-2 rounded-md bg-slate-800 text-white text-sm shadow-sm">{isDemoMode ? 'Run Demo Screening' : 'Run screening'}</button>
                                <button type="button" onClick={() => { setPatientId(''); setEyeImage(null); setEyePreview(null); setNailImage(null); setNailPreview(null); setIsDemoMode(false); }} className="px-3 py-1 rounded-md border border-slate-300 text-sm text-slate-700 dark:text-slate-200">Clear</button>
                                <div className="ml-auto text-xs text-slate-500">Demo mode: <button type="button" onClick={toggleDemoMode} className="underline">{isDemoMode ? 'On' : 'Off'}</button></div>
                            </div>
                        </form>
                    </div>

                    <div className="mt-4 p-3 bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/40 rounded-md shadow-sm text-sm">
                        <div className="font-medium text-slate-700 dark:text-slate-200">Model Output</div>
                        <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">Results are probabilistic. Use as an aid for clinical assessment.</div>
                    </div>
                </div>

                {/* Right sidebar: operator & quick metadata */}
                <aside className="col-span-1">
                    <div className="p-3 bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/40 rounded-md shadow-sm">
                        <div className="text-xs font-semibold text-slate-700 dark:text-slate-200">Operator</div>
                        <div className="mt-1 text-sm">Demo User</div>

                        <div className="mt-4 text-xs text-slate-500 dark:text-slate-400">Clinic: Demo Clinic 01</div>

                        <div className="mt-4">
                            <div className="text-xs font-medium text-slate-700 dark:text-slate-200">Recent</div>
                            <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">PID 00421 — Medium risk · 2h ago</div>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    );
};

export default NewScreening;
