# Firebase Authentication Setup Guide

## 1. Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project" or select an existing project
3. Follow the setup wizard

## 2. Enable Google Authentication

1. In Firebase Console, go to **Authentication** > **Sign-in method**
2. Click on **Google** provider
3. Toggle **Enable**
4. Add your project support email
5. Click **Save**

## 3. Register Your Web App

1. In Firebase Console, go to **Project Settings** (gear icon)
2. Scroll to "Your apps" section
3. Click the **Web** icon (`</>`)
4. Register your app with a nickname (e.g., "T7 MediScan AI")
5. Copy the `firebaseConfig` object

## 4. Update firebaseConfig.js

Open `src/firebaseConfig.js` and replace the placeholder values with your actual Firebase config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",                    // Replace this
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",  // Replace this
  projectId: "YOUR_PROJECT_ID",              // Replace this
  storageBucket: "YOUR_PROJECT_ID.appspot.com",   // Replace this
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",  // Replace this
  appId: "YOUR_APP_ID"                       // Replace this
};
```

## 5. Add Authorized Domains

1. In Firebase Console, go to **Authentication** > **Settings** > **Authorized domains**
2. Add your development domain (e.g., `localhost`)
3. Add your production domain when deploying

## 6. Test the Integration

1. Start your dev server: `npm run dev`
2. Click "Continue with Google" on the login page
3. Sign in with your Google account
4. You should be redirected to the main app

## Features Implemented

✅ **Google Sign-In**: Popup-based OAuth flow
✅ **Demo Mode**: Skip authentication for testing
✅ **localStorage Persistence**: Stay logged in after page refresh
✅ **User Display**: Shows user name/avatar in header
✅ **Sign Out**: Clear auth and return to login page
✅ **Error Handling**: User-friendly error messages
✅ **Loading States**: Visual feedback during sign-in

## File Structure

```
src/
├── firebaseConfig.js          # Firebase initialization
├── services/
│   └── auth.js                # Auth helper functions
├── components/
│   └── LoginPage.jsx          # Login UI with Google button
└── App.jsx                    # Auth state management
```

## Security Notes

⚠️ **Never commit your Firebase config with real values to public repositories**
⚠️ Set up Firebase Security Rules for production
⚠️ Enable App Check for additional security
⚠️ Use environment variables for sensitive config in production

## Troubleshooting

**"Popup closed by user"**: User closed the Google sign-in popup
- Solution: Try again and complete the sign-in flow

**"Unauthorized domain"**: Your domain isn't authorized in Firebase
- Solution: Add your domain to Authorized domains in Firebase Console

**"API key not valid"**: Incorrect Firebase configuration
- Solution: Double-check your firebaseConfig values

## Next Steps

- Implement phone/SMS authentication
- Add email/password sign-in
- Set up Firebase Security Rules
- Add user profile management
- Implement role-based access control (RBAC)
