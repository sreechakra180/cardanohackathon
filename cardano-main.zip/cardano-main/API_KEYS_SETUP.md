# 🔑 API Keys Setup Guide

## All API Keys You Need

### 1. 🔥 Firebase (Frontend Authentication)

**Where to get it:** https://console.firebase.google.com

**Steps:**
1. Go to Firebase Console
2. Select your project (or create a new one)
3. Click on Project Settings (gear icon) > General
4. Scroll down to "Your apps" section
5. Click on the web app icon `</>` or create a new web app
6. Copy the config values

**Add to:** `d:\cardano hackathon\screening-app\.env`

```env
VITE_FIREBASE_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789012
VITE_FIREBASE_APP_ID=1:123456789012:web:abcdef123456
```

---

### 2. ⛓️ Blockfrost (Cardano Blockchain - Backend)

**Where to get it:** https://blockfrost.io

**Steps:**
1. Create a free account at https://blockfrost.io
2. Click "Add Project"
3. Select **"Cardano Preprod"** network (NOT mainnet!)
4. Give it a name (e.g., "T7 MediScan")
5. Copy your Project ID (starts with `preprod...`)

**Set as environment variable (PowerShell):**
```powershell
$env:BLOCKFROST_PROJECT_ID="preprodYOUR_ACTUAL_PROJECT_ID_HERE"
```

**Or create:** `d:\cardano hackathon\backend\.env` (manually, since it's gitignored)
```env
BLOCKFROST_PROJECT_ID=preprodYOUR_ACTUAL_PROJECT_ID_HERE
```

---

### 3. 🤖 Groq (AI Chat Assistant - Backend)

**Where to get it:** https://console.groq.com

**Steps:**
1. Create a free account at https://console.groq.com
2. Go to "API Keys" section in the dashboard
3. Click "Create API Key"
4. Give it a name (e.g., "T7 MediScan Chat")
5. Copy the API key (starts with `gsk_...`)

**Set as environment variable (PowerShell):**
```powershell
$env:GROQ_API_KEY="gsk_YOUR_ACTUAL_GROQ_API_KEY_HERE"
```

**Or add to:** `d:\cardano hackathon\backend\.env`
```env
GROQ_API_KEY=gsk_YOUR_ACTUAL_GROQ_API_KEY_HERE
```

---

## Complete .env Files

### Frontend: `d:\cardano hackathon\screening-app\.env`

```env
# Firebase Authentication
VITE_FIREBASE_API_KEY=your_firebase_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_firebase_app_id

# Backend API URL
VITE_API_BASE_URL=http://localhost:8000
```

### Backend: `d:\cardano hackathon\backend\.env`

**Note:** This file is gitignored, so create it manually!

```env
# Blockfrost (Cardano Preprod)
BLOCKFROST_PROJECT_ID=preprodYOUR_PROJECT_ID_HERE

# Groq (AI Chat)
GROQ_API_KEY=gsk_YOUR_GROQ_API_KEY_HERE
```

---

## Quick Setup Commands

### Set Backend Environment Variables (PowerShell)

```powershell
# Navigate to backend directory
cd "d:\cardano hackathon\backend"

# Set Blockfrost Project ID
$env:BLOCKFROST_PROJECT_ID="preprodYOUR_ACTUAL_PROJECT_ID"

# Set Groq API Key
$env:GROQ_API_KEY="gsk_YOUR_ACTUAL_GROQ_KEY"

# Run the backend
uvicorn main:app --reload --port 8000
```

---

## Verification Checklist

- [ ] **Firebase**: Frontend `.env` file has all 6 Firebase config values
- [ ] **Blockfrost**: Backend has `BLOCKFROST_PROJECT_ID` set (preprod network)
- [ ] **Groq**: Backend has `GROQ_API_KEY` set
- [ ] Frontend runs without errors: `npm run dev`
- [ ] Backend runs without errors: `uvicorn main:app --reload`
- [ ] Backend health check works: `curl http://localhost:8000/health`

---

## Troubleshooting

### "BLOCKFROST_PROJECT_ID environment variable is required"
- Make sure you set the environment variable before running the backend
- Or create `backend/.env` file with the project ID

### "Firebase config not found"
- Check that `screening-app/.env` has all VITE_FIREBASE_* variables
- Restart the Vite dev server after adding .env file

### "Chat assistant unavailable"
- Make sure `GROQ_API_KEY` is set in backend environment
- Check that backend is running on port 8000
- Verify Groq API key is valid at https://console.groq.com

---

## Summary

**3 Services, 3 API Keys:**

1. **Firebase** → Frontend auth → Get from Firebase Console
2. **Blockfrost** → Backend blockchain → Get from Blockfrost.io (Preprod)
3. **Groq** → Backend AI chat → Get from Groq Console

All free tier accounts work perfectly for this hackathon project! 🚀
