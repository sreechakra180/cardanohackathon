# 🔑 API Keys Quick Reference

## You Need 3 API Keys Total

### 1. Firebase (Frontend - Already in `.env`)
**File:** `d:\cardano hackathon\screening-app\.env`
```env
VITE_FIREBASE_API_KEY=your_key_here
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abc123
```
**Get from:** https://console.firebase.google.com → Project Settings → Your apps

---

### 2. Blockfrost (Backend - Set as Environment Variable)
**Set in PowerShell:**
```powershell
$env:BLOCKFROST_PROJECT_ID="preprodYOUR_PROJECT_ID_HERE"
```
**Get from:** https://blockfrost.io → Create Project → Select "Cardano Preprod"

---

### 3. Groq (Backend - Set as Environment Variable)
**Set in PowerShell:**
```powershell
$env:GROQ_API_KEY="gsk_YOUR_GROQ_API_KEY_HERE"
```
**Get from:** https://console.groq.com → API Keys → Create API Key

---

## Quick Start Commands

### 1. Set Backend Environment Variables
```powershell
# Set both at once
$env:BLOCKFROST_PROJECT_ID="preprodYOUR_ACTUAL_ID"
$env:GROQ_API_KEY="gsk_YOUR_ACTUAL_KEY"
```

### 2. Run Backend
```powershell
cd "d:\cardano hackathon\backend"
uvicorn main:app --reload --port 8000
```

### 3. Run Frontend (in another terminal)
```powershell
cd "d:\cardano hackathon\screening-app"
npm run dev
```

---

## What Each Key Does

| Service | Purpose | Used In | Required For |
|---------|---------|---------|--------------|
| **Firebase** | User authentication (Google/Phone login) | Frontend | Login page |
| **Blockfrost** | Cardano blockchain IPFS pinning | Backend | Storing screening results on-chain |
| **Groq** | AI chat assistant | Backend | Chat widget in app |

---

## Full Documentation
See `API_KEYS_SETUP.md` for detailed step-by-step instructions!
